package domain.model;

public class GuestUser extends User {

	public GuestUser() {
		super("Guest");
	}

	public void registerUser() {

	}
}
